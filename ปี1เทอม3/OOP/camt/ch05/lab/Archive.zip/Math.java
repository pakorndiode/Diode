package camt.ch03.lab;

public class Math {
    static double PI = 3.14;

    static double mul(double var1, double var2) {
        return var1 * var2;
    }
}
