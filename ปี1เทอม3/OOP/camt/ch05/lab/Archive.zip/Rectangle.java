package camt.ch03.lab;

public class Rectangle {
    double width;
    double height;

    double calArea() {
        return Math.mul(this.width, this.height);
    }
}
